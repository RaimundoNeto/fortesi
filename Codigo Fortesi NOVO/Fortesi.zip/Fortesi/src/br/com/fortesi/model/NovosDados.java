package br.com.fortesi.model;

public class NovosDados {
	
	private int id;
	private String tipoacaon;
	private String condprocessualn;
	private String partecontrarian;
	private String advcontrarion;
	private String regiaon;
	private String secaon;
	private String subcecaon;
	private String cidade_comarcan;
	private String juizdireito_espn;
	private String forumn;
	private String varan;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTipoacaon() {
		return tipoacaon;
	}
	public void setTipoacaon(String tipoacaon) {
		this.tipoacaon = tipoacaon;
	}
	public String getCondprocessualn() {
		return condprocessualn;
	}
	public void setCondprocessualn(String condprocessualn) {
		this.condprocessualn = condprocessualn;
	}
	public String getPartecontrarian() {
		return partecontrarian;
	}
	public void setPartecontrarian(String partecontrarian) {
		this.partecontrarian = partecontrarian;
	}
	public String getAdvcontrarion() {
		return advcontrarion;
	}
	public void setAdvcontrarion(String advcontrarion) {
		this.advcontrarion = advcontrarion;
	}
	public String getRegiaon() {
		return regiaon;
	}
	public void setRegiaon(String regiaon) {
		this.regiaon = regiaon;
	}
	public String getSecaon() {
		return secaon;
	}
	public void setSecaon(String secaon) {
		this.secaon = secaon;
	}
	public String getSubcecaon() {
		return subcecaon;
	}
	public void setSubcecaon(String subcecaon) {
		this.subcecaon = subcecaon;
	}
	public String getCidade_comarcan() {
		return cidade_comarcan;
	}
	public void setCidade_comarcan(String cidade_comarcan) {
		this.cidade_comarcan = cidade_comarcan;
	}
	public String getJuizdireito_espn() {
		return juizdireito_espn;
	}
	public void setJuizdireito_espn(String juizdireito_espn) {
		this.juizdireito_espn = juizdireito_espn;
	}
	public String getForumn() {
		return forumn;
	}
	public void setForumn(String forumn) {
		this.forumn = forumn;
	}
	public String getVaran() {
		return varan;
	}
	public void setVaran(String varan) {
		this.varan = varan;
	}
	
	
}
